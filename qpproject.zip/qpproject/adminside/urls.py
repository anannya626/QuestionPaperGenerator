from django.urls import path
from .views import GeneratePDF
from . import views


urlpatterns = [
    path('', views.AdminLogin, name="AdminLogin"),
    path('AdminLogout', views.AdminLogout, name="AdminLogout"),
    path('AddCourse.html', views.AddCourse, name="AddCourse"),
    path('RegisteringTeachers.html', views.RegisteringTeachers, name="RegisteringTeachers"),
    path('SettingTemplate.html', views.SettingTemplate, name="SettingTemplate"),
    path('Settings.html', views.Settings, name="Settings"),
    path('FacultyLogin.html', views.FacultyLogin, name="FacultyLogin"),
    path('SelectCourse.html', views.SelectCourse, name="SelectCourse"),
    path('AddingQuestions.html', views.AddingQuestions, name="AddingQuestions"),
    path('Menu.html', views.Menu, name="Menu"),
    path('FacultyLogout',views.FacultyLogout, name="FacultyLogout"),
    path('CourseSelectToGenerate.html',views.CourseSelectToGen, name="CourseSelectToGenerate"),
    path('GeneralSetting.html',views.GeneralSettings, name="GeneralSettings"),
    path('delete_course/<course_id>',views.delete_course, name="delete_course"),
    path('delete_faculty/<faculty_id>',views.delete_faculty, name="delete_faculty"),
    path('CourseManagement.html',views.CourseManagement, name="CourseManagement"),
    path('FacultyManagement.html',views.FacultyManagement, name="FacultyManagement"),
    path('QuestionsManagement.html',views.QuestionsManagement, name="QuestionsManagement"),
    path('QuestionPaper.html',views.QuestionPaper, name="QuestionPaper"),
    path('ComparePDFs.html',views.ComparePDFs, name="ComparePDFs"),
    path('Mapping.html',views.Mapping, name="Mapping"),
    path('GeneratePDF', GeneratePDF.as_view(), name='GeneratePDF'),
    path('DisplaytoCompare.html',views.DisplaytoCompare, name="DisplaytoCompare"),
    path('DisplayGenerated.html',views.DisplayGenerated, name="DisplayGenerated"),
    path('open_compare',views.open_compare, name="open_compare"),
    path('open_compare_new',views.open_compare_new, name="open_compare_new"),
    path('Compare.html', views.Compare, name="Compare"),
    path('ViewQuestions.html', views.ViewQuestions, name="ViewQuestions"),
    path('QuestionsTable.html', views.QuestionsTable, name="QuestionsTable"),
    path('UpdateQuestions.html', views.UpdateQuestions, name="UpdateQuestions"),
    #path('update_questions/<questions_id>', views.update_questions, name="update_questions"),
    path('delete_questions/<questions_id>', views.delete_questions, name="delete_questions"),
    #path('FacultyRegister', views.FacultyRegister, name="FacultyRegister")
]
