from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import RegisteringTeachersTable, AddingCourse, Modules, Marks, TemplateTable, SelectedCoursetoGenerate, AddQn, Semester, Series, MappingCourse, CurrentlyLoggedIn, Settings, FinalQuestions, GeneratedPDFs, PrevPDF, SelectedCoursetoAdd, ComparePDF
from .models import RegisteringTeachersTable, AddingCourse, Modules, Marks, TemplateTable, SelectedCoursetoGenerate, AddQn, Semester, Series, MappingCourse, CurrentlyLoggedIn, Settings, FinalQuestions, GeneratedPDFs, PrevPDF, SelectedCoursetoAdd, ComparePDF, convertedimage
 #from adminside.models import Adminside
 #from .models import RegisterFaculty
 # Register your models here.

 #admin.site.register(RegisterFaculty)
 #class AdminsideAdmin(UserAdmin):
 #    list_display = ('email', 'username', 'date_joined', 'last_login', 'is_admin', 'is_staff')
 #    search_fields = ('email', 'username')
 #    readonly_fields = ('id', 'date_joined', 'last_login')

 #    filter_horizontal = ()
 #    list_filter = ()
 #    fieldsets = ()

 #admin.site.register(Adminside, AdminsideAdmin)
admin.site.register(RegisteringTeachersTable)
 #admin.site.register(MarkCombinations)
admin.site.register(AddingCourse)
admin.site.register(Modules)
admin.site.register(Marks)
admin.site.register(TemplateTable)
 #admin.site.register(PreviousYearPaper)
admin.site.register(SelectedCoursetoGenerate)
admin.site.register(AddQn)
admin.site.register(Semester)
admin.site.register(Series)
admin.site.register(MappingCourse)
admin.site.register(CurrentlyLoggedIn)
admin.site.register(Settings)
admin.site.register(FinalQuestions)
admin.site.register(GeneratedPDFs)
admin.site.register(PrevPDF)
admin.site.register(SelectedCoursetoAdd)
admin.site.register(ComparePDF)
admin.site.register(convertedimage)
