#from django import forms
#from .models import RegTeachers
#from django.forms import ModelForm
#from django import forms

#class LoginTeachers(ModelForm):
 #   class Meta:
  #      model = RegTeachers
   #     fields = ['username', 'password']

