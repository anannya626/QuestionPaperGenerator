from django.db import models
 #from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
 # Create your models here.

class RegisteringTeachersTable(models.Model):
     facname = models.CharField(max_length=60)
     facusername = models.CharField(max_length=60)
     facpassword = models.CharField(max_length=60)

     def __str__(self):
         return self.facname

 #class MarkCombinations(models.Model):
 #    MCname = models.CharField(max_length=60)
 #    MCFirstPart = models.IntegerField()
 #    MCSecondPart = models.IntegerField()

 #    def __str__(self):
 #        return self.MCname
class Semester(models.Model):
    semesterid = models.AutoField(primary_key=True)
    semestername = models.CharField(max_length=20)

    def __str__(self):
        return self.semestername
class AddingCourse(models.Model):
     courseid = models.AutoField(primary_key=True)
     coursename = models.CharField(max_length=100)
     coursecode = models.CharField(max_length=20, default=0)
     semestername = models.ForeignKey(Semester, default=0, on_delete=models.CASCADE)
     #facname = models.ManyToManyField(RegisteringTeachersTable, default=4)
     #facname = models.ForeignKey(RegisteringTeachersTable, default=11, on_delete=models.CASCADE)

     def __str__(self):
         return self.coursename

class MappingCourse(models.Model):
    mcid = models.AutoField(primary_key=True)
    coursename = models.ForeignKey(AddingCourse, on_delete=models.CASCADE)
    facname = models.ForeignKey(RegisteringTeachersTable, on_delete=models.CASCADE)
    questionlimit = models.IntegerField(default=5)

    def __str__(self):
        return '{}'.format(self.coursename)

class Series(models.Model):
    seriesid = models.AutoField(primary_key=True)
    seriesname = models.CharField(max_length=20)

    def __str__(self):
        return self.seriesname

class Modules(models.Model):
    moduleid = models.AutoField(primary_key=True)
    modulename = models.CharField(max_length=100)

    def __str__(self):
        return self.modulename

class Marks(models.Model):
    marksid = models.AutoField(primary_key=True)
    marksname = models.CharField(max_length=20)
    marksvalue = models.IntegerField(max_length=50)

    def __str__(self):
        return self.marksname

class TemplateTable(models.Model):
    templateid = models.AutoField(primary_key=True)
    sections = models.CharField(max_length=10)
    marksvalue = models.ForeignKey(Marks, on_delete=models.CASCADE)
    totalmarks = models.IntegerField(default=2, max_length=20)
    totalquestions = models.IntegerField(max_length=20)
    questionspermodule = models.IntegerField(max_length=20)

    def __str__(self):
        return self.sections

class SelectedCoursetoGenerate(models.Model):
    selectedid = models.AutoField(primary_key=True)
    coursename = models.ForeignKey(AddingCourse, on_delete=models.CASCADE)
    seriesname = models.ForeignKey(Series, default=1, on_delete=models.CASCADE)
    month = models.CharField(max_length=100, default='January')
    year = models.CharField(max_length=4, default=2022)
    moduleid = models.ForeignKey(Modules, on_delete=models.CASCADE)
     #modulequestions = models.IntegerField(max_length=10)

    def __str__(self):
        return '{}'.format(self.selectedid)

class AddQn(models.Model):
    addqnid = models.AutoField(primary_key=True)
    type_qn = models.CharField(max_length=1000)
    courseid = models.ForeignKey(AddingCourse, default=1, on_delete=models.CASCADE)
    marksvalue = models.ForeignKey(Marks, on_delete=models.CASCADE)
    modulename = models.ForeignKey(Modules, on_delete=models.CASCADE)
    image = models.ImageField(null=True, blank=True, upload_to="image/")
    facusername = models.ForeignKey(RegisteringTeachersTable, default=4, on_delete=models.CASCADE)

    def __str__(self):
        return self.type_qn

class CurrentlyLoggedIn(models.Model):
    clid = models.AutoField(primary_key=True)
    facusername = models.ForeignKey(RegisteringTeachersTable, on_delete=models.CASCADE)

    def __str__(self):
        return '{}'.format(self.facusername)

class Settings(models.Model):
    settingsid= models.AutoField(primary_key=True, default=1)
    questionsnumber = models.IntegerField(max_length=20)

    def __str__(self):
        return '{}'.format(self.questionsnumber)

class SelectedCoursetoAdd(models.Model):
    selectedid = models.AutoField(primary_key=True)
    coursename = models.ForeignKey(AddingCourse, on_delete=models.CASCADE)
    modulename = models.ForeignKey(Modules, on_delete=models.CASCADE)

    def __str__(self):
        return '{}'.format(self.coursename)

class FinalQuestions(models.Model):
    finalQuesid = models.AutoField(primary_key=True)
    selectedques = models.CharField(max_length=1000)
    coursename = models.ForeignKey(AddingCourse, default=1, on_delete=models.CASCADE)
    moduleid = models.CharField(max_length=20)
    marksvalue = models.ForeignKey(Marks, default=1, on_delete=models.CASCADE)
     #courseid = models.ForeignKey(AddingCourse, default=1, on_delete=models.CASCADE)
     #marksvalue = models.ForeignKey(Marks, on_delete=models.CASCADE)
     #modulename = models.ForeignKey(Modules, on_delete=models.CASCADE)
    image = models.ImageField(null=True, blank=True, upload_to='Settings')
     #facusername = models.ForeignKey(RegisteringTeachersTable, default=4, on_delete=models.CASCADE)

    def __str__(self):
        return '{}'.format(self.selectedques)

class GeneratedPDFs(models.Model):
    generatedid = models.AutoField(primary_key=True)
    coursename = models.ForeignKey(AddingCourse, default=1, on_delete=models.CASCADE)
    questionspdf = models.FileField(upload_to='QuestionPaper')

    def __str__(self):
        return '{}'.format(self.generatedid)

class PrevPDF(models.Model):
    previd = models.AutoField(primary_key=True)
    coursename = models.ForeignKey(AddingCourse, on_delete=models.CASCADE)
    prevpdf = models.FileField(upload_to='Settings')

class ComparePDF(models.Model):
    compareid = models.AutoField(primary_key=True)
    newpdflink = models.CharField(max_length=100)
    oldpdflink = models.CharField(max_length=100)

class convertedimage(models.Model):
    image= models.FileField(upload_to='Settings')

 #class CourseSelectedToGenerate(models.Model):
 #    courseselectedid = models.AutoField(primary_key=True)
 #    courseid = models.ForeignKey(AddingCourse, on_delete=model.CASCADE)
 #    coursename = models.ForeignKey(AddingCourse, on_delete=model.CASCADE)
 #    moduleid = models.

 #class AdminsideManager(BaseUserManager):
 #    def create_user(self, email, username, password=None):
 #        if not email:
 #            raise ValueError("Must have an email Address")
 #        if not username:
 #            raise ValueError("Must have a Username")
 #        user = self.model(
 #            email=self.normalize_email(email),
 #            username=username,
 #            password=password
 #        )
 #        user.set_password(password)
 #        user.save(using=self._db)
 #        return user
 #
 #    def create_superuser(self, email, username, password=None):
 #        user = self.create_user(
 #            email=self.normalize_email(email),
 #            #username=username,
 #            password=password,
 #        )
 #        user.is_admin = True
 #        user.is_staff = True
 #        user.is_superuser = True
 #        user.save(using=self._db)
 #        return user
 #
 #class Adminside(AbstractBaseUser):
 #    email = models.EmailField(verbose_name = "email", max_length=60, unique=True)
 #    username = models.CharField(max_length=30, unique=True)
 #
 #    date_joined = models.DateTimeField(verbose_name="date joined", auto_now_add=True)
 #    last_login = models.DateTimeField(verbose_name="last login", auto_now=True)
 #    is_admin = models.BooleanField(default=False)
 #    is_active = models.BooleanField(default=True)
 #    is_staff = models.BooleanField(default=False)
 #    is_superuser = models.BooleanField(default=False)
 #    hide_email = models.BooleanField(default=True)
 #
 #    objects = AdminsideManager()

 #    USERNAME_FIELD = 'email'
 #    REQUIRED_FIELD = ['username']

 #    def __str__(self):
 #        return self.username
 #
 #    def has_perm(self, perm, obj=None):
 #        return self.is_admin

 #    def has_module_perms(self, app_label):
 #        return True
