from django.shortcuts import render, redirect
from django.views.generic import View
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.http import HttpResponse, FileResponse
from django.contrib.auth.decorators import login_required
from adminside.util import render_to_pdf
from io import BytesIO
from django.core.files import File
from django.core.files.storage import FileSystemStorage
from difflib import Differ
from django.db.models import Count
import os.path
from pdf2image import convert_from_path, convert_from_bytes
from pdf2image.exceptions import (
    PDFInfoNotInstalledError,
    PDFPageCountError,
    PDFSyntaxError
)
#from tika import parser
from django.views.decorators.clickjacking import xframe_options_exempt
from django.views.decorators.clickjacking import xframe_options_sameorigin
#from .forms import FacultyAuthenticate, FacultyLoginAuthenticate
from .models import RegisteringTeachersTable, AddingCourse, Modules, Marks, TemplateTable,  SelectedCoursetoGenerate, AddQn, Semester, Series, MappingCourse, CurrentlyLoggedIn, Settings, FinalQuestions, GeneratedPDFs,PrevPDF, SelectedCoursetoAdd, ComparePDF, convertedimage
#from .forms import AdminsideAuthenticate
#from .models import RegisterFaculty
# Create your views here

#AdminLogin page
def AdminLogin(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')

        user=authenticate(request, username=username, password=password)
        if user is not None:
            login(request,user)
            return redirect("AddCourse")
        else:
            messages.info(request,'Username or Password is Incorrect')
    return render(request, 'AdminLogin.html', {})

#Admin Logout
def AdminLogout(request):
    logout(request)
    return redirect("AdminLogin")

#Add Course Page
@login_required(login_url="AdminLogin")
def AddCourse(request):
    sems = Semester.objects.all()
    facs = RegisteringTeachersTable.objects.all()
    if request.method == 'POST':
        if request.POST.get('semester'):
            course_name = request.POST['coursename']
            coursecode = request.POST['coursecode']
            semester = request.POST.get('semester')
            semcheck = Semester.objects.get(semestername=semester)
            diff = AddingCourse.objects.filter(coursename=course_name)
            if diff:
                messages.info(request, 'Course already added')
            else:
                AC = AddingCourse(coursename=course_name)
                AC.coursecode = coursecode
                AC.semestername = semcheck
                AC.save()
                if request.POST.get('fac1'):
                    facname1 = request.POST.get('fac1')
                    faccheck = RegisteringTeachersTable.objects.get(facname=facname1)
                    checkcourse = AddingCourse.objects.get(coursename=course_name)
                    AC = MappingCourse(coursename=checkcourse)
                    AC.facname = faccheck
                    AC.save()
                if request.POST.get('fac2'):
                    facname2 = request.POST.get('fac2')
                    faccheck = RegisteringTeachersTable.objects.get(facname=facname2)
                    checkcourse = AddingCourse.objects.get(coursename=course_name)
                    AC = MappingCourse(coursename=checkcourse)
                    AC.facname = faccheck
                    AC.save()
                    messages.info(request, 'Course Added')

                #return HttpResponse(course_name)
                #AC = AddingCourse(coursename=course_name)
                #AC.coursesemester = request.POST.get('semester')
                #AC.save()
                #messages.info(request,'Course Added')
            #if name:
            #    for var in name:
            #        #return HttpResponse(var)
            #        if var==course_name:
            #            #return HttpResponse(course_name)
            #            messages.info(request, 'Course already added')
            #        else:
                        #return HttpResponse(course_name)
            #            AC = AddingCourse(coursename=course_name)
            #            AC.coursesemester = request.POST.get('semester')
            #            AC.save()
            #            messages.info(request,'Course Added')
    else:
        return render(request, 'AddCourse.html', {"RegisteringTeachersTable":facs, "Semester":sems})
    return render(request, 'AddCourse.html', {"RegisteringTeachersTable":facs, "Semester":sems})


#def RegisteringTeachers(request, *args, **kwargs):
#    user = request.user
    #if user.is_authenticated:
        #return HttpResponse('Already Registered')
#    context = {}
#    if request.POST:
#        form = FacultyAuthenticate(request.POST)
#        if form.is_valid():
#            form.save()
#            messages.info(request,'Faculty Registered')
#        else:
#            context['Faculty_Authenticate'] = form
#    else:
#        form = FacultyAuthenticate(request.POST)
#        context['Faculty_Authenticate'] = form
#    return render(request, 'RegisteringTeachers.html', {})

#Template Setting page
@login_required(login_url="AdminLogin")
def SettingTemplate(request):
    marksdetails = Marks.objects.all()
    #return HttpResponse(marksdetails)
    if request.method =="POST":
        if request.POST.get('SectionSelect'):
            TemplateTable.objects.all().delete()
            sectionsselected = request.POST.get('SectionSelect')
            #return HttpResponse(sectionsselected)
            if sectionsselected == '1':
                if request.POST.get('Amarks'):
                    #return HttpResponse(request.POST.get('Amarks'))
                    Amarks = Marks.objects.get(marksvalue=request.POST.get('Amarks'))
                    Temp = TemplateTable(sections='A')
                    Temp.marksvalue=Amarks
                    Temp.totalquestions = request.POST.get('Anoofques')
                    Temp.totalmarks = request.POST.get('Atotalmarks')
                    Temp.questionspermodule = request.POST.get('Anumber')
                    Temp.save()
                    messages.info(request,'Template Set')
            if sectionsselected == '2':
                if request.POST.get('Amarks'):
                    #return HttpResponse(request.POST.get('Amarks'))
                    Amarks = Marks.objects.get(marksvalue=request.POST.get('Amarks'))
                    Temp = TemplateTable(sections='A')
                    Temp.marksvalue=Amarks
                    Temp.totalquestions = request.POST.get('Anoofques')
                    Temp.totalmarks = request.POST.get('Atotalmarks')
                    Temp.questionspermodule = request.POST.get('Anumber')
                    Temp.save()
                if request.POST.get('Bmarks'):
                    Bmarks = Marks.objects.get(marksvalue=request.POST.get('Bmarks'))
                    Temp = TemplateTable(sections='B')
                    Temp.marksvalue=Bmarks
                    Temp.totalquestions = request.POST.get('Bnoofques')
                    Temp.totalmarks = request.POST.get('Btotalmarks')
                    Temp.questionspermodule = request.POST.get('Bnumber')
                    Temp.save()
                    messages.info(request,'Template Set')

    return render(request, 'SettingTemplate.html', {"Marks":marksdetails})

#Settings page
@login_required(login_url="AdminLogin")
def Settings(request):
    if request.method=="POST":
        FinalQuestions.objects.all().delete()
        selectedcname = SelectedCoursetoGenerate.objects.values_list('coursename')
        selectedmods = SelectedCoursetoGenerate.objects.values_list('moduleid')
        #return HttpResponse(selectedmods)
        #for x in selectedcname:
        #    for i in x:
        #        cname = AddingCourse.objects.filter(courseid=i)

        #for x in selectedmods:
        #    for i in x:
        #        mods = Modules.objects.filter(moduleid=i)
                #return HttpResponse(mods)
        templatedata = TemplateTable.objects.values_list('marksvalue')
        #return HttpResponse(templatedata)
        mark=Marks.objects.values_list('pk')
        #return HttpResponse(mark)
        questions =[]
        #questions = AddQn.objects.filter(marksvalue__in=mark)
        #return HttpResponse(questions)
        #QUERY FOR ALL
        #for mar in mark:
        #    for mod in selectedmods:
            #return HttpResponse(b)
        #        questions.extend(list(AddQn.objects.filter(courseid__in=selectedcname, modulename__in=mod, marksvalue__in=mar).order_by("?")[:2]))
                #mods.extend(list(AddQn.objects.filter(courseid__in=selectedcname, modulename__in=mod, marksvalue__in=mar).values_list('modulename').order_by("?")[:2]))
            #questionslist.append(questions)
        #for mar in mark:
        #    for mod in selectedmods:
        #        if mar==2:
        #            questionslist.extend(list(AddQn.objects.filter(courseid__in=selectedcname, modulename__in=mod, marksvalue__in=mar).order_by("?")[:2]))
        #            break;
        #return HttpResponse(questionlist)
        #SAVING BOTH TOGETHER
        #for x in questions:
        #    SV=FinalQuestions()
        #    SV.selectedques=x
        #    SV.save()
        #return HttpResponse(questions)
            #for y in mark:
            #    for m in y:
            #        if m==
            #questionslist.append(questions)
            #return HttpResponse(questions)

        #for x in templatedata:
        #    for i in x:

        #        for y in questions:
        #            return HttpResponse(y)
        #return HttpResponse(templatedata)
        cname = AddingCourse.objects.get(pk__in=selectedcname)
        #FQ = FinalQuestions()
        #FQ.coursename = cname
        #FQ.save()
        finalmods = Modules.objects.filter(pk__in=selectedmods)
        questionslist_2 = []
        questionslist_6 = []
        count=0
        limit_2 = TemplateTable.objects.values_list('questionspermodule')[0]
        limit_6 = TemplateTable.objects.values_list('questionspermodule')[1]
        #return HttpResponse(limit_2)
        for x in templatedata:
            for i in x:
                mark_2 = Marks.objects.filter(marksvalue=i)
        for x in templatedata:
            for i in x:
                mark_6 = Marks.objects.filter(pk=i)
        for mod in selectedmods:
            for lim in limit_2:
                questionslist_2.extend(list(AddQn.objects.filter(courseid__in=selectedcname, modulename__in=mod, marksvalue__in=mark_2).values('type_qn','modulename','image').order_by("?")[:lim]))
            #print(questionslist_2)
            # for z in mark_2:
            #     FQ.marksvalue = z
            #     FQ.save()
            #     for i in questionslist_2:
            #         FQ.selectedques = i
            #         FQ.save()
        #FQ = FinalQuestions()
        #for
        #FQ.selectedques = questionslist_2
            #return HttpResponse(questionslist_2)
            #SV = FinalQuestions()
            #return HttpResponse(questionslist_2)
        #SAVING 6 MARKS INTO THE DATABASE
        for x in questionslist_2:
            #return HttpResponse(x['type_qn'])
            for i in mark_2:
                SV = FinalQuestions(selectedques=x['type_qn'], coursename=cname, moduleid=x['modulename'], marksvalue=i, image=x['image'])
                SV.save()

            #    count=count+1
                #return HttpResponse(x)
                #SV.marksvalue = y
                #SV.coursename(cname)
                #SV.moduleid.add(mod)
                #SV.save()
            #for i in mark_2:
            #    SV.marksvalue.add(i)
            #    print(SV.marksvalue)
            #    SV.save()
            #return HttpResponse()
                #print("Count =",count)
            #return HttpResponse(SV.save())
        #return HttpResponse(selectedmods)
        #SAVING 6 MARKS INTO THE DATABASE
        for mod in selectedmods:
            for lim in limit_6:
                questionslist_6.extend(list(AddQn.objects.filter(courseid__in=selectedcname, modulename__in=mod, marksvalue__in=mark_6).values('type_qn','modulename','image').order_by("?")[:lim]))
            #SV = FinalQuestions(moduleid=mod)
            #SV.save()
        for x in questionslist_6:

            #return HttpResponse(x['image'])
            for i in mark_6:
                SV = FinalQuestions(selectedques=x['type_qn'], coursename=cname, moduleid=x['modulename'], marksvalue=i, image=x['image'])
                SV.save()
            #return HttpResponse(questionslist_6)
        #    SV = FinalQuestions()
        #    for x in questionslist_6:
                #return HttpResponse(x)
        #        SV.selectedques = x
            #return HttpResponse(questionslist_6)
        #    SV.coursename = cname
        #    SV.moduleid = mod
        #    for i in mark_6:
        #        SV.marksvalue = i
        #    SV.save()
        #return HttpResponse(questionslist_6)
        #for mod in selectedmods:

        #return HttpResponse(mark)
        messages.info(request, "Now click on the Generate PDF to view and download the question paper pdf")
        #return redirect('QuestionPaper')
        #return HttpResponse(mark)
        #return HttpResponse(mark)
    return render(request, 'Settings.html', {})
@xframe_options_exempt
def QuestionPaper(request):
    mark = Marks.objects.values_list('marksvalue')[0]
    selectedcourse = SelectedCoursetoGenerate.objects.values_list('coursename')
    selectedseries = SelectedCoursetoGenerate.objects.values_list('seriesname')
    month = SelectedCoursetoGenerate.objects.values_list('month')[0]
    year = SelectedCoursetoGenerate.objects.values_list('year')[0]
    Aquesnumbers = TemplateTable.objects.values_list('questionspermodule')[0]
    Atemplatedata = TemplateTable.objects.values_list('totalquestions')[0]
    Atotalmarks = TemplateTable.objects.values_list('totalmarks')[0]
    Bquesnumbers = TemplateTable.objects.values_list('totalquestions')[1]
    #Atemplatedata = TemplateTable.objects.values_list('totalquestions')[0]
    Btotalmarks = TemplateTable.objects.values_list('totalmarks')[1]
    #return HttpResponse(quesnumbers)
    #return HttpResponse(selectedseries)
    for b in Bquesnumbers:
        Bquesnumberfinal = int(b/2)
    #return HttpResponse(Bquesnumberfinal)
    for x, y in zip(Atotalmarks, Btotalmarks):
        maxmark = x+y
    #return HttpResponse(maxmark)
    coursename = AddingCourse.objects.filter(pk__in=selectedcourse)
    coursecode = AddingCourse.objects.filter(pk__in=selectedcourse).values_list('coursecode')
    semestername = AddingCourse.objects.filter(pk__in=selectedcourse).values_list('semestername')
    coursesemester = Semester.objects.filter(pk__in=semestername)
    series = Series.objects.filter(pk__in=selectedseries)
    #return HttpResponse(series)
    templatedata = TemplateTable.objects.values_list('marksvalue')
    for x in templatedata:
        for i in x:
            mark_2 = Marks.objects.filter(marksvalue=i)
    finalquestionslist_2 = FinalQuestions.objects.filter(marksvalue__in=mark_2)
    #finalimage_2 = FinalQuestions.objects.filter(marksvalue__in=mark_2).values_list('image')
    #return HttpResponse(finalimage_2)
    for x in templatedata:
        for i in x:
            mark_6 = Marks.objects.filter(pk=i)
    finalquestionslist_6 = FinalQuestions.objects.filter(marksvalue__in=mark_6)
    secondsectioncount=finalquestionslist_6.count()
    modules = FinalQuestions.objects.values_list('moduleid')
    for x in Atemplatedata:
        countofA = x

    #selectedcname = SelectedCoursetoGenerate.objects.values_list('coursename')
    #cname = AddingCourse.objects.get(pk__in=selectedcname)
    #return HttpResponse(countofA)
    settingcounter = 0
    context= {
        "finalquestionslist_2":finalquestionslist_2,
        #"finalimage_2":finalimage_2,
        "finalquestionslist_6":finalquestionslist_6,
        "coursename":coursename,
        "coursecode":coursecode,
        "coursesemester":coursesemester,
        "series":series,
        "month":month,
        "year":year,
        "Aquesnumbers":Aquesnumbers,
        "Atemplatedata":Atemplatedata,
        "Atotalmarks":Atotalmarks,
        "Bquesnumberfinal":Bquesnumberfinal,
        "Btotalmarks":Btotalmarks,
        "maxmark":maxmark,
        "secondsectioncount":secondsectioncount,
        "modules":modules,
        "countofA":countofA
    }

    #return HttpResponse(nameofpdf)
    #finalquestionslist_6 = FinalQuestions.objects.all()[i:]
    #return render(request,'QuestionPaper.html', context)
    #html= render(request, 'QuestionPaper.html', context)
    pdf = render_to_pdf('QuestionPaper.html', context)
    if pdf:
        response = HttpResponse(pdf, content_type='application/pdf',)
        for i,x in zip(coursename,series):
            filename = "%s%s.pdf" %(i,x)
            cname = i
        # return HttpResponse(cname)
        # SV = GeneratedPDFs()
        # SV.coursename = cname
        # SV.save()
        # obj = GeneratedPDFs.objects.all()
        # return HttpResponse(obj)
        content = "inline; filename=%s" %(filename)
        response['Content-Disposition'] = content
        #filecontent =
        pdffile = (filename, File(BytesIO(pdf.content)))
        SV = GeneratedPDFs(coursename=cname)
        #return HttpResponse(SV)
        SV.questionspdf.save(filename, File(BytesIO(pdf.content)))
        #return HttpResponse(pdf.content)
        #SV.save()
        return response
    return HttpResponse("Not found")
    #pdf = render_to_pdf('QuestionPaper.html', context)
    #return HttpResponse(pdf, content_type='pdf')
class GeneratePDF(View):
    def get(self, *args, **kwargs):
        pdf = render_to_pdf('QuestionPaper.html', data)
        return HttpResponse(pdf, content_type='application/pdf')

def CourseSelectToGen(request):
    showcourses = AddingCourse.objects.all()
    showmods = Modules.objects.all()
    showseries = Series.objects.all()
    if request.method=="POST":
        #return HttpResponse("POst is working")
        if request.POST.get('selectcoursename') and request.POST.get('selectseries') and request.POST.get('month'):
            SelectedCoursetoGenerate.objects.all().delete()
            coursename = request.POST.get('selectcoursename')
            selectedcourse = request.POST.get('selectcoursename')
            selectedseries = request.POST.get('selectseries')
            month = request.POST.get('month')
            year = request.POST['year']
            selectedcoursefinal = AddingCourse.objects.get(coursename=selectedcourse)
            selectedseriesfinal = Series.objects.get(seriesname=selectedseries)
            if request.POST.get('selectmodnumber'):
                selectedmodnumber = request.POST.get('selectmodnumber')
                if selectedmodnumber=='1':
                    if request.POST.get('selectmod1'):
                        #quesnumber = request.POST['mod1ques']
                        selectmod1 = Modules(moduleid=request.POST.get('selectmod1'))
                        TempCourse = SelectedCoursetoGenerate()
                        TempCourse.coursename=selectedcoursefinal
                        TempCourse.seriesname=selectedseriesfinal
                        TempCourse.moduleid=selectmod1
                        TempCourse.month=month
                        TempCourse.year=year
                        #TempCourse.modulequestions=quesnumber
                        TempCourse.save()
                        #messages.info(request, 'Selected')
                        #return render(request, 'Settings.html', {"coursename":coursename.upper(), })
                if selectedmodnumber=='2':
                    if request.POST.get('selectmod1'):
                            selectmod1 = Modules(moduleid=request.POST.get('selectmod1'))
                            TempCourse = SelectedCoursetoGenerate()
                            TempCourse.coursename=selectedcoursefinal
                            TempCourse.seriesname=selectedseriesfinal
                            TempCourse.moduleid=selectmod1
                            TempCourse.month=month
                            TempCourse.year=year
                            TempCourse.save()
                            #messages.info(request, 'Selected')
                    if request.POST.get('selectmod2'):
                            selectmod2 = Modules(moduleid=request.POST.get('selectmod2'))
                            TempCourse = SelectedCoursetoGenerate()
                            TempCourse.coursename=selectedcoursefinal
                            TempCourse.seriesname=selectedseriesfinal
                            TempCourse.moduleid=selectmod2
                            TempCourse.month=month
                            TempCourse.year=year
                            TempCourse.save()
                #if selectedmodnumber=='3':
                #    if request.POST.get('selectmod1'):
                #            selectmod1 = Modules(moduleid=request.POST.get('selectmod1'))
                #            TempCourse = SelectedCoursetoGenerate()
                #            TempCourse.coursename=selectedcoursefinal
                #            TempCourse.seriesname=selectedseriesfinal
                #            TempCourse.moduleid=selectmod1
                #            TempCourse.save()
                            #messages.info(request, 'Selected')
                #    if request.POST.get('selectmod2'):
                #            selectmod2 = Modules(moduleid=request.POST.get('selectmod2'))
                #            TempCourse = SelectedCoursetoGenerate()
                #            TempCourse.coursename=selectedcoursefinal
                #            TempCourse.seriesname=selectedseriesfinal
                #            TempCourse.moduleid=selectmod2
                #            TempCourse.save()
                #    if request.POST.get('selectmod3'):
                #            selectmod3 = Modules(moduleid=request.POST.get('selectmod3'))
                #            TempCourse = SelectedCoursetoGenerate()
                #            TempCourse.coursename=selectedcoursefinal
                #            TempCourse.seriesname=selectedseriesfinal
                #            TempCourse.moduleid=selectmod3
                #            TempCourse.save()
                #if selectedmodnumber=='4':
                #    if request.POST.get('selectmod1'):
                #            selectmod1 = Modules(moduleid=request.POST.get('selectmod1'))
                #            TempCourse = SelectedCoursetoGenerate()
                #            TempCourse.coursename=selectedcoursefinal
                #            TempCourse.seriesname=selectedseriesfinal
                #            TempCourse.moduleid=selectmod1
                #            TempCourse.save()
                            #messages.info(request, 'Selected')
                #    if request.POST.get('selectmod2'):
                #            selectmod2 = Modules(moduleid=request.POST.get('selectmod2'))
                #            TempCourse = SelectedCoursetoGenerate()
                #            TempCourse.coursename=selectedcoursefinal
                #            TempCourse.seriesname=selectedseriesfinal
                #            TempCourse.moduleid=selectmod2
                #            TempCourse.save()
                #    if request.POST.get('selectmod3'):
                #            selectmod3 = Modules(moduleid=request.POST.get('selectmod3'))
                #            TempCourse = SelectedCoursetoGenerate()
                #            TempCourse.coursename=selectedcoursefinal
                #            TempCourse.seriesname=selectedseriesfinal
                #            TempCourse.moduleid=selectmod3
                #            TempCourse.save()
                #    if request.POST.get('selectmod4'):
                #            selectmod4 = Modules(moduleid=request.POST.get('selectmod4'))
                #            TempCourse = SelectedCoursetoGenerate()
                #            TempCourse.coursename=selectedcoursefinal
                #            TempCourse.seriesname=selectedseriesfinal
                #            TempCourse.moduleid=selectmod4
                #            TempCourse.save()
                #if selectedmodnumber=='5':
                #        if request.POST.get('selectmod1'):
                #                selectmod1 = Modules(moduleid=request.POST.get('selectmod1'))
                #                TempCourse = SelectedCoursetoGenerate()
                #                TempCourse.coursename=selectedcoursefinal
                #                TempCourse.seriesname=selectedseriesfinal
                #                TempCourse.moduleid=selectmod1
                #                TempCourse.save()
                                #messages.info(request, 'Selected')
                #        if request.POST.get('selectmod2'):
                #                selectmod2 = Modules(moduleid=request.POST.get('selectmod2'))
                #                TempCourse = SelectedCoursetoGenerate()
                #                TempCourse.coursename=selectedcoursefinal
                #                TempCourse.seriesname=selectedseriesfinal
                #                TempCourse.moduleid=selectmod2
                #                TempCourse.save()
                #        if request.POST.get('selectmod3'):
                #                selectmod3 = Modules(moduleid=request.POST.get('selectmod3'))
                #                TempCourse = SelectedCoursetoGenerate()
                #                TempCourse.coursename=selectedcoursefinal
                #                TempCourse.seriesname=selectedseriesfinal
                #                TempCourse.moduleid=selectmod3
                #                TempCourse.save()
                #        if request.POST.get('selectmod4'):
                #                selectmod4 = Modules(moduleid=request.POST.get('selectmod4'))
                #                TempCourse = SelectedCoursetoGenerate()
                #                TempCourse.coursename=selectedcoursefinal
                #                TempCourse.seriesname=selectedseriesfinal
                #                TempCourse.moduleid=selectmod4
                #                TempCourse.save()
                #        if request.POST.get('selectmod5'):
                #                selectmod5 = Modules(moduleid=request.POST.get('selectmod5'))
                #                TempCourse = SelectedCoursetoGenerate()
                #                TempCourse.coursename=selectedcoursefinal
                #                TempCourse.seriesname=selectedseriesfinal
                #                TempCourse.moduleid=selectmod5
                #                TempCourse.save()

                            #return render(request, 'Settings.html', {"coursename":coursename.upper(), })
                            #messages.info(request, 'Selected')
                else:
                        messages.info(request, 'Submit failed')
            #getcheckfinal=[]


            #return HttpResponse(coursename)
            return redirect('Settings')
    #return HttpResponse(showcourses)
    return render(request, 'CourseSelectToGenerate.html', {"AddingCourse":showcourses, "Modules":showmods, "Series":showseries})

#Menu(which i must learn to extend)
def Menu(request):
    return render(request, 'Menu.html', {})

#Select Course page
#@login_required(login_url="FacultyLogin")
def SelectCourse(request):
    showfac = CurrentlyLoggedIn.objects.values_list('facusername')
    #for x in showfac:
        #return HttpResponse(x)
        #showfacfinal = RegisteringTeachersTable.objects.get(pk=x)
    #return HttpResponse(showfacfinal)
    showcourses = MappingCourse.objects.values_list('facname')
    for show in showfac:
        for x in show:
            showcoursesfinal = MappingCourse.objects.filter(facname=x)

        #break;
            #return HttpResponse(showcoursesfinal)
    showmodules = Modules.objects.all()
    if request.method == 'POST':
        if request.POST.get('selectcoursename') and request.POST.get('selectmodulename'):
            faculty = CurrentlyLoggedIn.objects.values_list('facusername')
            #return HttpResponse(faculty)
            originalfac = RegisteringTeachersTable.objects.filter(pk__in=faculty).select_related()
            mainlimit = MappingCourse.objects.values_list('questionlimit')[0]
            templatedata = TemplateTable.objects.values_list('marksvalue')
            for x in templatedata:
                for i in x:
                    mark_2 = Marks.objects.filter(marksvalue=i)
            for x in templatedata:
                for i in x:
                    mark_6 = Marks.objects.filter(pk=i)
                #return HttpResponse(x)
            course = request.POST.get('selectcoursename')
            module= request.POST.get('selectmodulename')
            #return HttpResponse(module)
            selectedcoursefinal = AddingCourse.objects.filter(coursename=course)
            courseselect = AddingCourse.objects.get(coursename=course)
            selectedmodfinal = Modules.objects.get(moduleid=module)
            question_2= AddQn.objects.filter(facusername__in=originalfac, modulename__in=module, marksvalue__in=mark_2, courseid__in=selectedcoursefinal).select_related().count()
            question_6= AddQn.objects.filter(facusername__in=originalfac, modulename__in=module, marksvalue__in=mark_6, courseid__in=selectedcoursefinal).select_related().count()
            #return HttpResponse(question_2)
            for x in mainlimit:
                limit = x
            if question_2>=limit and question_6>=limit:
                messages.info(request, "Limit Exceeded!")
                return render(request, 'SelectCourse.html', {"Modules":showmodules, "showcoursesfinal":showcoursesfinal})
            elif question_2<=limit and question_6<=limit:
                course = request.POST['selectcoursename'].upper()
                modules = request.POST['selectmodulename']
                SelectedCoursetoAdd.objects.all().delete()
                SV = SelectedCoursetoAdd(coursename=courseselect , modulename=selectedmodfinal)
                SV.save()
                return redirect('AddingQuestions')
    #return HttpResponse(showcourses)
    return render(request, 'SelectCourse.html', {"Modules":showmodules, "showcoursesfinal":showcoursesfinal})

#Adding Questions page
def AddingQuestions(request):
    course = AddingCourse.objects.filter(pk__in=SelectedCoursetoAdd.objects.values_list('coursename'))
    mods = Modules.objects.filter(pk__in=SelectedCoursetoAdd.objects.values_list('modulename'))
    faculty = CurrentlyLoggedIn.objects.values_list('facusername')
    currentlimit = MappingCourse.objects.values_list('questionlimit')[0]
    #return HttpResponse(faculty)
    originalfac = RegisteringTeachersTable.objects.filter(pk__in=faculty).select_related()
    mainlimit = MappingCourse.objects.values_list('questionlimit')[0]
    templatedata = TemplateTable.objects.values_list('marksvalue')
    for x in templatedata:
        for i in x:
            mark_2 = Marks.objects.filter(marksvalue=i)
    for x in templatedata:
        for i in x:
            mark_6 = Marks.objects.filter(pk=i)
        #return HttpResponse(x)

    question_2= AddQn.objects.filter(facusername__in=originalfac, modulename__in=mods, marksvalue__in=mark_2, courseid__in=course).select_related().count()
    question_6= AddQn.objects.filter(facusername__in=originalfac, modulename__in=mods, marksvalue__in=mark_6, courseid__in=course).select_related().count()
    questionlist_2= AddQn.objects.filter(marksvalue__in=mark_2, courseid__in=course, facusername__in=originalfac).values('type_qn', 'marksvalue', 'modulename')
    questionlist_6= AddQn.objects.filter(marksvalue__in=mark_6, courseid__in=course, facusername__in=originalfac).values('type_qn', 'marksvalue', 'modulename')
    mainlimit = MappingCourse.objects.values_list('questionlimit')[0]
    for x in mainlimit:
        limit = x
    if question_2>=limit and question_6>=limit:
        return redirect('SelectCourse')
    markslist = Marks.objects.all()
    if request.method=="POST":
        type_qn=request.POST.get('type_qn')
        marks = request.POST.get('marks')
        #return HttpResponse(marks)
        courses = AddingCourse.objects.filter(pk__in=SelectedCoursetoAdd.objects.values_list('coursename')).select_related()
        modsfin = Modules.objects.filter(pk__in=SelectedCoursetoAdd.objects.values_list('modulename')).select_related()
        marksfinal = Marks.objects.filter(marksname=marks).select_related()
        #return HttpResponse(courses)
        if marks is None:
            messages.info(request, 'Did Not Save')
        elif AddQn.objects.filter(type_qn=type_qn).exists():
            messages.info(request, 'Question already in the database')
        elif len(request.FILES)!=0:
            image = request.FILES['image']
            for y,i,x,o in zip(courses,modsfin,marksfinal,originalfac):
                #return HttpResponse(i)
                addqn=AddQn(type_qn=type_qn, courseid=y, marksvalue=x, modulename=i, image=image, facusername=o)
                addqn.save()
                messages.info(request, 'Question Added with Image')
                return render(request, 'AddingQuestions.html', {"course":course,"mods":mods,"Marks":markslist,"question_2":question_2,"question_6":question_6, "questionlist_2":questionlist_2, "questionlist_6": questionlist_6, "currentlimit":currentlimit, "mark_2":mark_2, "mark_6":mark_6})
        elif len(request.FILES)==0:
            for y,i,x,o in zip(courses,modsfin,marksfinal,originalfac):
                addqn=AddQn(type_qn=type_qn, courseid=y, marksvalue=x, modulename=i, facusername=o)
                addqn.save()
                messages.info(request, 'Question Added')
                return render(request, 'AddingQuestions.html', {"course":course,"mods":mods,"Marks":markslist,"question_2":question_2,"question_6":question_6, "questionlist_2":questionlist_2, "questionlist_6": questionlist_6, "currentlimit":currentlimit, "mark_2":mark_2, "mark_6":mark_6})
        else:
            messages.info(request, 'Did Not Save')
    #return HttpResponse(questionlist_6)
    #mainlimit = MappingCourse.objects.filter(facname__in=originalfac).values(questionlimit)[0]
    #return HttpResponse(question_6)
    return render(request, 'AddingQuestions.html', {"course":course,"mods":mods,"Marks":markslist,"question_2":question_2,"question_6":question_6, "questionlist_2":questionlist_2, "questionlist_6": questionlist_6, "currentlimit":currentlimit, "mark_2":mark_2, "mark_6":mark_6})

#Registering Teachers page
def ViewQuestions(request):
    showfac = CurrentlyLoggedIn.objects.values_list('facusername')
    showcourses = MappingCourse.objects.values_list('facname')
    for show in showfac:
        for x in show:
            showcoursesfinal = MappingCourse.objects.filter(facname=x)
    if request.method=="POST":
        course = AddingCourse.objects.filter(coursename=request.POST['courseselected'])
        # course =
        faculty = CurrentlyLoggedIn.objects.values_list('facusername')
        originalfac = RegisteringTeachersTable.objects.filter(pk__in=faculty).select_related()
        questionlist_2= AddQn.objects.filter(courseid__in=course, facusername__in=originalfac)
        # return HttpResponse(questionlist_2)
        return render(request, 'QuestionsTable.html', {"questionlist_2":questionlist_2})
    return render(request, 'ViewQuestions.html', {"showcoursesfinal":showcoursesfinal})
def QuestionsTable(request):
    return render(request, 'QuestionsTable.html', {})
@login_required(login_url="AdminLogin")

def RegisteringTeachers(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['username']
        password = request.POST['password']
        #username = RegisteringTeachersTable.objects.values_list('facusername')
        #return HttpResponse(username)
        #pword = RegisteringTeachersTable.objects.values_list('facpassword')
        diff = RegisteringTeachersTable.objects.filter(facusername=email)
        if diff:
            messages.info(request, 'Username already in use')
        else:
            Rt = RegisteringTeachersTable(facname=name, facusername=email, facpassword=password)
            Rt.save()
            messages.info(request,'Faculty Registered')
        #checkemail=0
        #if username:
            #return HttpResponse(username)
        #    for mail in username:
        #        return HttpResponse(mail)
        #        if mail == email:

        #            checkemail=1
        #if checkemail==1:
        #    messages.info(request, 'Username already in use')

    else:
        return render(request, 'RegisteringTeachers.html', {})
    return render(request, 'RegisteringTeachers.html', {})

#Faculty Login Page
def FacultyLogin(request):
    if request.POST:
        CurrentlyLoggedIn.objects.all().delete()
        email = request.POST['email']
        password = request.POST['password']
        #pword = RegisteringTeachersTable.objects.values_list('facpassword')

        if not RegisteringTeachersTable.objects.filter(facusername=email, facpassword=password).exists():
            messages.info(request, 'Username or Password is incorrect')
        else:
            username = RegisteringTeachersTable.objects.get(facusername=email)
            FCL = CurrentlyLoggedIn(facusername=username)
            #return HttpResponse(FCL)
            FCL.save()
            return redirect('SelectCourse')
        #checkpassword = RegisteringTeachersTable.objects.get(facpassword=password)
        #if checkmail is None:
        #     messages.info(request, 'Username is incorrect')
        #if checkpassword is None:
        #    messages.info(request, 'Password is incorrect')
        #else:
        #    return redirect('SelectCourse')
    else:
        return render(request, 'FacultyLogin.html', {})
    return render(request, 'FacultyLogin.html', {})
#        checkemail=0
#        checkpassword=0
#        for email in username:
#            checkemail=1
#        for password in pword:
#            checkpassword=1
#        if checkemail and checkpassword==1:
#            return redirect('SelectCourse')
#        else:
#            messages.info(request, 'Username or Password is incorrect')
#    else:
#        return render(request, 'FacultyLogin.html', {})
#    return render(request, 'FacultyLogin.html', {})

def FacultyLogout(request):
    CurrentlyLoggedIn.objects.all().delete()
    return redirect('FacultyLogin')

@xframe_options_exempt
def GeneralSettings(request):
    showcourses = AddingCourse.objects.all()
    currentlimit = MappingCourse.objects.values_list('questionlimit')[0]
    if request.method == 'POST':
        if request.POST.get('selectcoursename'):
            cname = request.POST.get('selectcoursename')
            cnamefinal = AddingCourse.objects.get(coursename=cname)
            SV = PrevPDF(coursename=cnamefinal)
            #SV.save()
            prevpdf = request.FILES['prev']
            #return HttpResponse(prevpdf)
            SV.prevpdf.save(prevpdf.name, prevpdf)
            messages.info(request, "Saved!")
        if request.POST.get('queslimit'):
            limit = request.POST.get('queslimit')
            MappingCourse.objects.all().update(questionlimit=limit)
            messages.info(request, "Limit Set!")
        return render(request, 'GeneralSettings.html',{"showcourses":showcourses,"currentlimit":currentlimit})
        # if request.POST.get('number_button'):
        #     Settings.objects.all().delete()
        #     quesnum = request.POST['quesnum']
        #     return HttpResponse(quesnum)
        #     SV=Settings()
        #     SV.questionsnumber=quesnum
        #     SV.save()
        #     messages.info(request, "Question Number Added!")
    return render(request, 'GeneralSettings.html',{"showcourses":showcourses,"currentlimit":currentlimit})

def delete_course(request, course_id):
    if course_id:
        getcourseid = AddingCourse.objects.get(courseid=course_id)
        getcourseid.delete()
        messages.info(request,"Course Deleted Successfully!")
        return redirect('GeneralSettings')

def delete_faculty(request, faculty_id):
    if faculty_id:
        getfacultyid = RegisteringTeachersTable.objects.get(pk=faculty_id)
        getfacultyid.delete()
        messages.info(request,"Faculty Deleted Successfully!")
        return redirect('GeneralSettings')
def delete_questions(request, questions_id):
    if questions_id:
        getquestionsid = AddQn.objects.get(pk=questions_id)
        getquestionsid.delete()
        messages.info(request,"Question Deleted Successfully!")
        return redirect('ViewQuestions')
def UpdateQuestions(request):
    return render(request, 'UpdateQuestions.html', {})
#EDITING
# def update_questions(request, questions_id):
#     if questions_id:
#         mark = Marks.objects.all()
#         getquestionid = AddQn.objects.get(pk=questions_id)
#         if request.method=="POST":
#             type_qn=request.POST.get('type_qn')
#             marks = request.POST.get('marks')
#             marksfinal = Marks.objects.filter(marksname=marks).select_related()
#             if len(request.FILES)!=0:
#                 image = request.FILES['image']
#                 for m in marksfinal:
#                     SV = AddQn.objects.get(pk=questions_id)
#                     SV.type_qn = type_qn
#                     SV.marksvalue = m
#                     SV.image=image
#                     SV.save()
#                     messages.info(request,"Question Updated with Image Successfully!")
#                     return redirect('ViewQuestions')
#             else:
#                 for m in marksfinal:
#                     SV = AddQn.objects.get(pk=questions_id)
#                     return HttpResponse(type_qn)
#                     SV.type_qn = type_qn
#                     SV.marksvalue = m
#                     SV.save()
#                     messages.info(request,"Question Updated Successfully!")
#                     return redirect('ViewQuestions')
#         return render(request, 'update_questions.html', {"getquestionid":getquestionid, "Marks":mark})
    #return HttpResponse(course_id)

    #return HttpResponse(getcourseid)
#def add_previouspaper(request):
    #if request.method='POST':
@xframe_options_exempt
def ComparePDFs(request):
    pdf = PrevPDF.objects.values_list('prevpdf')
    pdftrying = PrevPDF.objects.all()
    # for p in pdf:
    #     return HttpResponse(p.path)
    pdfgenerated = GeneratedPDFs.objects.values_list('questionspdf')
    if request.method == "POST":
        if request.POST.get('previous') and request.POST.get('new'):
            #return HttpResponse(request.POST.get('previous'))
            openprev = PrevPDF.objects.filter(prevpdf=request.POST.get('previous')).values_list('prevpdf')
            #return HttpResponse(openprev)
            for prev in openprev:
                previous = prev
            opennew = GeneratedPDFs.objects.filter(questionspdf=request.POST.get('new')).values_list('questionspdf')
            for new in opennew:
                news = new
            # for prev, new in zip(openprev,opennew):
            #     SV = ComparePDFs()
            #     SV.questionspdf = new
            #     SV.prevpdf = prev
            #     SV.save()
            #return HttpResponse(opennew)
            # for x in openprev:
            #     data = open(x, 'rb')
            # response = FileResponse(data)
            first = request.POST.get('previous')
            second = request.POST.get('new')
            file_path = 'media/'+first
            file_path_new = 'media/'+second
            BASE = os.path.dirname(os.path.abspath(__file__))
            data = open(file_path, 'rb')
            # with open(file_path, 'rb') as pdf:
            #     with open(file_path_new, 'rb') as pdf2:
            #         difference = pdfdiff(pdf,pdf2)
            # return HttpResponse(difference)
            with open(file_path, 'rb') as pdf:
                pages = convert_from_bytes(pdf.read(), 700)
            for page in pages:
                 page.save('media/out.jpeg', 'JPEG')
            convertedimage.objects.all().delete()
            SV = convertedimage(image='out.jpeg')
            SV.save()
            images = convertedimage.objects.all()
            #print(page)
            # pages = convert_from_bytes(open(file_path, 'rb').read())
            # #pages = convert_from_path(r'media/Settings/ADS_Questions_Paper_a1S5BRj.pdf', 500)
            # for page in pages:
            #     return page
            # tr = data.read()
            #response = FileResponse(data)
            #return response
            data2 = open(file_path_new, 'rb')
            # response = FileResponse(data2, content_type='application/pdf')
            # return response
            # tr2 = data2.read()
            # raw = parser.from_file(file_path)
            # return HttpResponse(raw['content'])
            # difference = pdfdiff(file_path,file_path_new)
            # return HttpResponse(difference)
            # #return HttpResponse(BASE)
            # # for o in openprev:
            # data = open(os.path.join(BASE, 'media/Settings/ADS_Questions_Paper_a1S5BRj.pdf'))
            # print( os.path.isfile(file_path))
            # difference = pdfdiff(os.path.join(file_path), os.path.join(file_path_new))
            # return HttpResponse(difference)
            # firsttry = first.replace(os.sep, "\")
            # return HttpResponse(firsttry)

            # return FileResponse(open(first, 'rb'), content_type='application/pdf')
            #return HttpResponse(first)
            # ComparePDF.objects.all().delete()
            # SV = ComparePDF(newpdflink=second, oldpdflink=first)
            # SV.save()
            # first = ComparePDF.objects.values_list('oldpdflink')
            # #return HttpResponse(first)
            # for f in first:
            #     for x in f:
            #     #return HttpResponse(f)
            #         return FileResponse(open(x, 'rb'), content_type='application/pdf')
            # hello = FileResponse(open(first, 'rb'))
            # seconds = FileResponse(open(second, 'rb'))
            # BASE = os.path.dirname(os.path.abspath(__file__))
            # #return HttpResponse(BASE)
            # # for o in openprev:
            # data = open(os.path.join(BASE, 'media/Settings/ADS_Questions_Paper_a1S5BRj.pdf'))
            # # pdf = open(os.path.join('/media/Settings/ADS_Questions_Paper_a1S5BRj.pdf'))
            # response = FileResponse(pdf)
            # return response
            # difference = pdfdiff('ADS_Questions_Paper_a1S5BRj.pdf','Data_StructureFirst_Series_SYYSHQv.pdf')
            # return HttpResponse(difference)
            return render(request, 'DisplaytoCompare.html',{"previous":previous,"news":news, "convertedimage":images})
            response ['Content-Security-Policy'] = "frame-ancestors 'self' http://127.0.0.1:8000/"
            #return redirect('DisplaytoCompare')
            #return HttpResponse(opennew)
    # for p in pdf:
    #     return FileResponse(open(p, 'rb'), content_type='application/pdf')
    # with open('C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series.pdf') as file_1, open('C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series_aYB0vwk.pdf') as file_2:
    #     new = pdf-diff(file_1, file_2)
    # return HttpResponse(new)
    # from difflib import Differ
    # with open('C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series.pdf') as file_1, open('C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series_aYB0vwk.pdf') as file_2:
    #     differ = Differ()
    #     for line in differ.compare(file_1.readlines(), file_2.readlines()):
    #         print(line)
            #return render(request, 'test.html',{})
            #return HttpResponse(line)
    # with open('C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series.pdf') as pdf1:
    #     pdf1_text = pdf1.readlines()
    # with open('C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series_aYB0vwk.pdf') as pdf2:
    #     pdf2_text = pdf2.readlines()
    # for line in difflib.unified_diff(
    #     pdf1_text, pdf2_text, fromfile='C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series.pdf',
    #     tofile='C:\\Users\\User\\Documents\\Django_Projects\\qpprojects\\media\\QuestionPaper\\Data_StructureFirst_Series_aYB0vwk.pdf', lineterm=''):
    #     return HttpResponse(line)
    #if request.method == "POST":

    return render(request, 'ComparePDFs.html', {"PrevPDF":pdf,"GeneratedPDFs":pdfgenerated})
@xframe_options_exempt
def Compare(request):
    mark = Marks.objects.values_list('marksvalue')[0]
    selectedcourse = SelectedCoursetoGenerate.objects.values_list('coursename')
    selectedseries = SelectedCoursetoGenerate.objects.values_list('seriesname')
    month = SelectedCoursetoGenerate.objects.values_list('month')[0]
    year = SelectedCoursetoGenerate.objects.values_list('year')[0]
    Aquesnumbers = TemplateTable.objects.values_list('questionspermodule')[0]
    Atemplatedata = TemplateTable.objects.values_list('totalquestions')[0]
    Atotalmarks = TemplateTable.objects.values_list('totalmarks')[0]
    Bquesnumbers = TemplateTable.objects.values_list('totalquestions')[1]
    #Atemplatedata = TemplateTable.objects.values_list('totalquestions')[0]
    Btotalmarks = TemplateTable.objects.values_list('totalmarks')[1]
    #return HttpResponse(quesnumbers)
    #return HttpResponse(selectedseries)
    for b in Bquesnumbers:
        Bquesnumberfinal = int(b/2)
    #return HttpResponse(Bquesnumberfinal)
    for x, y in zip(Atotalmarks, Btotalmarks):
        maxmark = x+y
    #return HttpResponse(maxmark)
    coursename = AddingCourse.objects.filter(pk__in=selectedcourse)
    coursecode = AddingCourse.objects.filter(pk__in=selectedcourse).values_list('coursecode')
    semestername = AddingCourse.objects.filter(pk__in=selectedcourse).values_list('semestername')
    coursesemester = Semester.objects.filter(pk__in=semestername)
    series = Series.objects.filter(pk__in=selectedseries)
    #return HttpResponse(series)
    templatedata = TemplateTable.objects.values_list('marksvalue')
    for x in templatedata:
        for i in x:
            mark_2 = Marks.objects.filter(marksvalue=i)
    finalquestionslist_2 = FinalQuestions.objects.filter(marksvalue__in=mark_2)
    #finalimage_2 = FinalQuestions.objects.filter(marksvalue__in=mark_2).values_list('image')
    #return HttpResponse(finalimage_2)
    for x in templatedata:
        for i in x:
            mark_6 = Marks.objects.filter(pk=i)
    finalquestionslist_6 = FinalQuestions.objects.filter(marksvalue__in=mark_6)
    secondsectioncount=finalquestionslist_6.count()
    modules = FinalQuestions.objects.values_list('moduleid')
    for x in Atemplatedata:
        countofA = x

    #selectedcname = SelectedCoursetoGenerate.objects.values_list('coursename')
    #cname = AddingCourse.objects.get(pk__in=selectedcname)
    #return HttpResponse(countofA)
    settingcounter = 0
    context= {
        "finalquestionslist_2":finalquestionslist_2,
        #"finalimage_2":finalimage_2,
        "finalquestionslist_6":finalquestionslist_6,
        "coursename":coursename,
        "coursecode":coursecode,
        "coursesemester":coursesemester,
        "series":series,
        "month":month,
        "year":year,
        "Aquesnumbers":Aquesnumbers,
        "Atemplatedata":Atemplatedata,
        "Atotalmarks":Atotalmarks,
        "Bquesnumberfinal":Bquesnumberfinal,
        "Btotalmarks":Btotalmarks,
        "maxmark":maxmark,
        "secondsectioncount":secondsectioncount,
        "modules":modules,
        "countofA":countofA
    }
    return render(request, 'Compare.html',context)

def DisplaytoCompare(request):
    return render(request, 'DisplaytoCompare', {})
def open_compare(request):
    first = ComparePDF.objects.values_list('oldpdflink')
    return HttpResponse(first)
    for f in first:
        #return HttpResponse(f)
        return FileResponse(open(f, 'rb'), content_type='application/pdf')
    #return HttpResponse(first)
def open_compare_new(request):
    first = ComparePDF.objects.values_list('newpdflink')
    for f in first:
        return FileResponse(open(f, 'rb'), content_type='application/pdf')
def DisplayGenerated(request):
    pdftrying = GeneratedPDFs.objects.all()
    return render(request, 'DisplayGenerated.html', {"GeneratedPDFs":pdftrying})

def CourseManagement(request):
    coursedetails = AddingCourse.objects.all()
    #coursesem = AddingCourse.objects.values_list('semestername')
    #semester = Semester.objects.filter(pk__in=coursesem)
    facdetails = RegisteringTeachersTable.objects.values_list('pk')
    #return HttpResponse(coursedetails)
    mapped = MappingCourse.objects.values('coursename')
    newlist=[]
    mappedfac=MappingCourse.objects.filter(facname__in=facdetails).values_list('facname').annotate(Count('coursename', distinct=True))
    #mappedfac=dict(MappingCourse.objects.values_list('coursename'), newlist.append(list(MappingCourse.objects.values_list('facname'))))
    faclist={}

    # for i,x in zip(mappedfac,coursedetails):
    #     if x['coursename']==i['coursename']:
    #         newlist.append(i['facname'])
    #         faclist[i['coursename']]=newlist
    #return HttpResponse(mapped)
    return render(request, 'CourseManagement.html', {"AddingCourse":coursedetails,"mappedfac":mappedfac})
def FacultyManagement(request):
    facultydeets = RegisteringTeachersTable.objects.all()
    return render(request, 'FacultyManagement.html', {"RegisteringTeachersTable":facultydeets})
def QuestionsManagement(request):
    questionsdeets = AddQn.objects.all()
    #return HttpResponse(questionsdeets)
    return render(request, 'QuestionsManagement.html', {"AddQn":questionsdeets})
def Mapping(request):
    #facdetails = RegisteringTeachersTable.objects.values_list('pk')
    #facdeets = MappingCourse.objects.values('facname')
    #return HttpResponse(facdeets)
    #mappedfac=MappingCourse.objects.filter(facname__in=facdetails).values_list('coursename','facname').annotate(Count('coursename', distinct=True))
    #return HttpResponse(mappedfac)
    deets = MappingCourse.objects.all()
    return render(request, 'Mapping.html', {"MappingCourse":deets})

    #messages.info(request,"Course Deleted Successfully!")
    #coursedetails = AddingCourse.objects.all()
    #return render(request, 'GeneralSetting.html',{})
    #return HttpResponse(courseid)
#def FacultyLogin(request, *args, **kwargs):
#    context = {}

#    if request.POST:
#        form = FacultyLoginAuthenticate(request.POST)
#        if form.is_valid():
#            form.save()
#            return redirect("SelectCourse")
        #email = request.POST['facemail']
            #password = request.POST['facpassword']
            #return HttpResponse({email}, {password})
        #user = authenticate(email=email)
        #if user:
            #login(request, user)
            #destination = get_redirect_if_exist(request)
            #if destination:
                #return redirect(destination)
            #return redirect("SelectCourse")
        #else:
            #context['Faculty_LoginAuthenticate'] = form
            #return render(request, 'FacultyLogin.html', context)
#        else:
#            form = FacultyLoginAuthenticate(request.POST)
#            context['Faculty_LoginAuthenticate'] = form
#            messages.info(request,'Username or Password is Incorrect')
#    return render(request, 'FacultyLogin.html', {})
#def get_redirect_if_exist(request):
#    redirect = None
#    if request.GET:
#        if request.GET.get("next"):
#            redirect = str(request.GET.get("next"))
#    return redirect
